document.addEventListener('DOMContentLoaded', (event) => {
    const name = localStorage.getItem('name');
    document.getElementById('greeting').textContent = `Hi ${name}! Where would you put yourself?`;
    const categories = ['Seeking Personal Growth', 'Navigation Life Challenges', 'Need a Listening Ear']; // replace with your categories
    const subcategories = {
        'Seeking Personal Growth': ['Self Improvement 1', 'Mindful Practitioner', 'Emotion Seekers', 'Life-long Learners'], // replace with your subcategories
        'Navigation Life Challenges': ['Stress Management', 'Relationship Navigation', 'Seeking Sleep','Anxiety Fighting'],
        'Need a Listening Ear': ['Seeking Solitude', 'Late Night thinking','Emotional Venting','Heart to Heart talking']
    };

    const categoryContainer = document.getElementById('category-container');
    const subcategoryContainer = document.getElementById('subcategory-container');
    const selectedCategoryElement = document.getElementById('selected-category');
    const nextPageButton = document.getElementById('next-page');

    categories.forEach((category, index) => {
        const button = document.createElement('button');
        button.id = `button${index + 1}`; // Assign a unique id to each button
        button.textContent = category;
        button.addEventListener('click', () => {
            selectedCategoryElement.textContent = category;
            subcategoryContainer.style.display = 'block';
            displaySubcategories(category);
            document.querySelectorAll('#categories button').forEach(button => {
                button.classList.remove('selected');
            });
            button.classList.add('selected');
        });
        document.getElementById('categories').appendChild(button);
    });

    function displaySubcategories(category) {
        const subcategoryButtons = subcategories[category].map((subcategory,index) => {
            const button = document.createElement('button');
            button.textContent = subcategory;
            button.id = `${category.replace(/ /g, '')}-button${index + 1}`; // Assign a unique id to each subcategory button
            button.addEventListener('click', () => {
                nextPageButton.style.display = 'block';
                document.querySelectorAll('#subcategories button').forEach(button => {
                    button.classList.remove('selected');
                });
                button.classList.add('selected');
            });
            return button;
        });
        document.getElementById('subcategories').innerHTML = '';
        subcategoryButtons.forEach(button => document.getElementById('subcategories').appendChild(button));
    }

    nextPageButton.addEventListener('click', () => {
        // Go to the next page
        window.location.href = '/chat1';
    });
});

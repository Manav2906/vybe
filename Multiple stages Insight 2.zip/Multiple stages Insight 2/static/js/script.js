// Helper function to create a message element
function createMessageElement(text, className, url = null) {
    // Create a message wrapper div
    const messageWrapper = document.createElement('div');
    messageWrapper.classList.add(className);

    // Add message text to the message
    const messageText = document.createElement('span');
    messageText.textContent = text;
    messageWrapper.appendChild(messageText);

    // If a URL is provided, create a clickable link
    if (url) {
        const link = document.createElement('a');
        link.href = url;
        link.target = '_blank';
        link.textContent = 'this form';
        messageWrapper.appendChild(link);
    }

    return messageWrapper;

}

document.addEventListener('DOMContentLoaded', async (event) => {
    const form = document.querySelector('.form');
    const input = document.querySelector('.input');
    const chatContent = document.querySelector('.chat-content');

    let userId = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        if (!input.value.trim()) return;

        const userMessage = createMessageElement(input.value.trim(), 'user-message');
        chatContent.appendChild(userMessage);

        const typingMessage = createMessageElement('typing...', 'bot-message');
        chatContent.appendChild(typingMessage);

        try {
                const response = await fetch('/chat1', {
                    method: 'POST',
                    body: JSON.stringify({
                        'user_id': userId,
                        'message': input.value
                    }),
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });

            typingMessage.remove();

            if (!response.ok) throw new Error('Server responded with an error');

            const data = await response.json();
            const botMessage = createMessageElement(data['response'], 'bot-message');
            chatContent.appendChild(botMessage);
            chatContent.scrollTop = chatContent.scrollHeight;
        } catch (error) {
            const errorMessageContent = `
                🌟 Hey there! 🌟\n
                
                It looks like you've reached the end of your free trial with Insight. We've cherished our time together and hope you found value in our chats. If you'd like to continue this journey of self-discovery and emotional well-being, we'd love to have you on board!\n
                
                To keep the conversations going, please fill out 
            `;
            const googleFormUrl = "https://forms.gle/73H6JC7S6KDZ9zk28";
            const errorMessage = createMessageElement(errorMessageContent, 'bot-message', googleFormUrl);
            chatContent.appendChild(errorMessage);
            console.error('Error:', error);
        }

        input.value = '';
        input.focus();
    });

    // Modal functionality
    const helpModal = document.getElementById('helpModal');
    const helpBtn = document.querySelector('.help');
    const closeModal = document.querySelector('.help-modal-close');

    helpBtn.addEventListener('click', () => {
        helpModal.style.display = 'block';
    });

    closeModal.addEventListener('click', () => {
        helpModal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
        if (event.target === helpModal) {
            helpModal.style.display = 'none';
        }
    });
});

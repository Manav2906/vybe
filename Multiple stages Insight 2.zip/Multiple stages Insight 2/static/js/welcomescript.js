document.getElementById('next-button').addEventListener('click', () => {
    document.getElementById('next-button').addEventListener('click', () => {
    const name = document.getElementById('name-input').value;
    if (name) {
        window.location.href = `/category?name=${encodeURIComponent(name)}`;
    }
});
});

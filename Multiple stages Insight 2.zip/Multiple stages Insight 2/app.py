from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from chain import ConversationCache, chat
import globals
import asyncio
import os 
# Call the init function from globals.py
globals.init()

# Now you can import the chains
from globals import OBJECTIVE_THOUGHT_CHAIN, OBJECTIVE_RESPONSE_CHAIN

app = Flask(__name__)
CORS(app)

# Define a route for the welcome page
@app.route('/welcome', methods=['GET'])
def welcome():
    return render_template('welcome.html')

# Define a route for the category page
@app.route('/category', methods=['GET'])
def category():
    return render_template('category.html')

conversations = {}

async def chat_and_save( local_chain: ConversationCache, input: str) -> tuple[str, str]:
    thought_chain =  globals.OBJECTIVE_THOUGHT_CHAIN 
    response_chain = globals.OBJECTIVE_RESPONSE_CHAIN

    if local_chain.message_count == 20:
        input = generate_summary(input)
        local_chain.message_count = 0
    else:
        local_chain.message_count += 1

    thought = await chat(
        inp=input,
        thought_chain=thought_chain,
        thought_memory=local_chain.thought_memory
    )
    response = await chat(
        inp=input,
        thought=thought,
        response_chain=response_chain,
        response_memory=local_chain.response_memory
    )
    local_chain.thought_memory.save_context({"input":input}, {"output": thought})
    local_chain.response_memory.save_context({"input":input}, {"output": response})
    return thought, response

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat1', methods=['GET', 'POST'])
def chat2():
    if request.method == 'GET':
        return render_template('index.html')
    else: # 'POST'
        data = request.get_json()
        user_id = data['user_id']
        message = data['message']
    if user_id not in conversations:
        conversations[user_id] = ConversationCache()

    local_chain = conversations[user_id]

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    thought, response = loop.run_until_complete(chat_and_save(local_chain, message))

    return jsonify({'response': response})


if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)
